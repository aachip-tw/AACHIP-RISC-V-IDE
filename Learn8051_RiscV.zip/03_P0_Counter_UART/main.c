/*
 * 教學：P0 加一並以 UART 傳送
 * 接線：UART TX=P3.6，RX=P3.7；固定 115200、8-N-1。
 * 流程：先增加數值並輸出 P0，再傳同一個原始 byte；傳送完成才進下一輪。
 * Watch：p0_value、uart_value、uart_count
 * 平台：MAGIC1 RV32IM／ILP32，程式SRAM 512KB、資料BRAM 16KB。
 * 使用方式：F7重新編譯、下載ELF；RUN持續執行，需STOP或斷點才會暫停。
 */
#include "aachip8051.h"

/* 目前的八位計數值；255 加 1 轉回 uint8_t 後成為 0。 */
volatile uint8_t p0_value;
/* 最後已確認傳送完成的資料，不是 UART 接收值。 */
volatile uint8_t uart_value;
/* 已完成的傳送次數；32-bit 無號整數也會在最大值後回零。 */
volatile uint32_t uart_count;
/* 主程式由純C# startup完成資料初始化與堆疊設定後呼叫。 */
int main(void)
{
    /* 建立已知狀態：停Timer／中斷、設P0輸出、UART恢復115200並清殘留RX。 */
    board_init();
    for (;;) {
        /* 放慢每次加一，方便觀察 P0 與設定來源斷點。 */
        soft_delay(100000u);
        /* 第一筆為 0x01，接著 0x02～0xFF、0x00，持續循環。 */
        p0_value = (uint8_t)(p0_value + 1u);
        /* 先更新 P0 實體輸出。 */
        p0_write(p0_value);
        /* 阻塞到 stop bit 完成才返回；傳的是二進位 byte，不是 ASCII 數字。 */
        uart_send(p0_value);
        /* 在傳送函式返回後才更新，適合設斷點確認執行順序。 */
        uart_value = p0_value;
        /* 完成本輪後再回到迴圈，所以下一次增加不會早於這次傳送完成。 */
        uart_count++;
    }
}
