# 03 P0 加1後傳送 UART

接線：TX=P3.6；可接相容邏輯電位UART接收器，GND共地；P3.6接P3.7可回送。

開啟本目錄的 `03_P0_Counter_UART.rvproj`，F7編譯、連線、下載ELF，再按RUN。預設純C# O0，方便單步學習；在實際敘述行設斷點，不選只有大括號的行。

預期結果：P0與UART原始byte皆為01..FF、00循環；115200、8-N-1。

Watch：p0_value、uart_value、uart_count。

接收軟體選HEX模式；傳送的不是ASCII數字。

共同設定及8051差異見 [總說明](../README.md)。測試狀態見 [驗證紀錄](../VALIDATION.md)。

## 程式中文導讀

完整流程與預期結果見 [程式中文說明](程式中文說明.md)。
