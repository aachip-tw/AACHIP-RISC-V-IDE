/*
 * 教學：LED 閃爍與位元反轉
 * 接線：觀察 P0.0；LED 有效極性依板卡接線而定。
 * 流程：初始化後，反轉 led、輸出 P0、累計次數，再做軟體延遲。
 * Watch：led、blink_count
 * 平台：MAGIC1 RV32IM／ILP32，程式SRAM 512KB、資料BRAM 16KB。
 * 使用方式：F7重新編譯、下載ELF；RUN持續執行，需STOP或斷點才會暫停。
 */
#include "aachip8051.h"

/* 已進行幾次反轉；volatile 讓除錯觀察與記憶體內容保持一致。 */
volatile uint32_t blink_count;
/* 僅使用 bit0，初值由 startup 清為 0。 */
volatile uint8_t led;
/* 主程式由純C# startup完成資料初始化與堆疊設定後呼叫。 */
int main(void)
{
    /* 建立已知狀態：停Timer／中斷、設P0輸出、UART恢復115200並清殘留RX。 */
    board_init();
    for (;;) {
        /* XOR 1 只反轉最低位，相當於常見 8051 的 LED 位元翻轉。 */
        led ^= 1u;                 /* 相當於反轉 8051 P0.0。 */
        /* 共用函式只修改 P0，保留 P1／P2／P3 的輸出值。 */
        p0_write(led);
        /* 完成一次輸出就累加；數值不是精密時間。 */
        blink_count++;
        /* 拉長肉眼可見時間；最佳化等級和指令執行速度都會影響延遲。 */
        soft_delay(100000u);
    }
}
