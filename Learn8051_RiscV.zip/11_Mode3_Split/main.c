/*
 * 教學：Timer0 mode3 分拆成兩個八位計時器
 * 接線：不需額外接線；P0 高低四位顯示兩個計數器的溢位次數。
 * 流程：TL0 使用 TR0／TF0，TH0 使用 TR1／TF1；輪詢並分別 ACK。
 * Watch：tl0_overflows、th0_overflows
 * 平台：MAGIC1 RV32IM／ILP32，程式SRAM 512KB、資料BRAM 16KB。
 * 使用方式：F7重新編譯、下載ELF；RUN持續執行，需STOP或斷點才會暫停。
 */
#include "aachip8051.h"

/* TL0 溢位次數，使用原 Timer0 的 TF0／ACK bit1。 */
volatile uint32_t tl0_overflows;
/* TH0 溢位次數，借用原 Timer1 的 TF1／ACK bit3。 */
volatile uint32_t th0_overflows;
/* 主程式由純C# startup完成資料初始化與堆疊設定後呼叫。 */
int main(void)
{
    /* 建立已知狀態：停Timer／中斷、設P0輸出、UART恢復115200並清殘留RX。 */
    board_init();
    /* 50MHz/50000=1kHz，每次計數間隔1ms。 */
    TIMER_CLOCK = 50000; /* 1kHz。 */
    /* 低四位3使Timer0分拆；高四位3停止原Timer1，避免與教學混淆。 */
    TMOD = 0x33; /* T0 mode3分拆；T1 mode3停止。 */
    /* TL0由0起算，首次256ms；TH0由128起算，首次128ms。 */
    TL0 = 0; TH0 = 128;
    /* TR0控制TL0、TR1控制TH0；TH0只能使用內部tick。 */
    TCON = TR0 | TR1; /* TL0用TR0，TH0用TR1。 */
    for (;;) {
        /* 先讀同一份旗標值，再分別處理，不對ACK做read-modify-write。 */
        uint32_t flags = TCON;
        /* 寫ACK bit1只清TF0，不會清除同時發生的TF1。 */
        if (flags & TF0) { IRQ_ACK = ET0; tl0_overflows++; }
        /* 寫ACK bit3清TH0旗標；不是原Timer1在這個模式的中斷。 */
        if (flags & TF1) { IRQ_ACK = ET1; th0_overflows++; }
        /* 低四位顯示TL0次數、高四位顯示TH0次數，各自模16。 */
        p0_write((uint8_t)((tl0_overflows & 15u) | ((th0_overflows & 15u) << 4)));
    }
}
