# 11 Mode3 分拆兩個8位 Timer

接線：P0八位LED；不需額外接線。

開啟本目錄的 `11_Mode3_Split.rvproj`，F7編譯、連線、下載ELF，再按RUN。預設純C# O0，方便單步學習；在實際敘述行設斷點，不選只有大括號的行。

預期結果：TL0首次約256ms溢位；TH0首次約128ms溢位，之後兩者各256ms。P0低／高4位分別顯示次數。

Watch：tl0_overflows、th0_overflows。

TH0固定用內部tick，不受C/T1與GATE1控制。若還要Timer1供UART，可改TMOD=0x23；此時Timer1不受TR1控制且不產生TF1。

共同設定及8051差異見 [總說明](../README.md)。測試狀態見 [驗證紀錄](../VALIDATION.md)。

## 程式中文導讀

完整流程與預期結果見 [程式中文說明](程式中文說明.md)。
