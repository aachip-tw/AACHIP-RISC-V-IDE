# 12 UART 256-byte 實體迴路自測

接線：將P3.6（TX）接P3.7（RX），移除這兩腳的其他訊號輸出。

開啟本目錄的 `12_UART_Loopback_Test.rvproj`，F7編譯、連線、下載ELF，再按RUN。預設純C# O0，方便單步學習；在實際敘述行設斷點，不選只有大括號的行。

預期結果：測試00..FF全部256個byte；成功為done=1、pass_count=256、error_count=0。

Watch：pass_count、error_count、done、tx_value、rx_value。

沒有跳線時會因接收逾時結束；done=1表示自測完成，CPU仍在最後的迴圈，請按STOP或設斷點查看。

共同設定及8051差異見 [總說明](../README.md)。測試狀態見 [驗證紀錄](../VALIDATION.md)。

## 程式中文導讀

完整流程與預期結果見 [程式中文說明](程式中文說明.md)。
