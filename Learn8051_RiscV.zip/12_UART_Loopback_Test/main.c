/*
 * 教學：UART 00～FF 共 256-byte 實體迴路自測
 * 接線：只將 P3.6 TX 接 P3.7 RX，移除其他會驅動這兩腳的訊號。
 * 流程：逐 byte 傳送、等待 RX、比較；最後 done=1，保留結果供 Watch 查看。
 * Watch：pass_count、error_count、done、tx_value、rx_value
 * 平台：MAGIC1 RV32IM／ILP32，程式SRAM 512KB、資料BRAM 16KB。
 * 使用方式：F7重新編譯、下載ELF；RUN持續執行，需STOP或斷點才會暫停。
 */
#include "aachip8051.h"

/* 比較正確的 byte 數，正常完成應為256。 */
volatile uint32_t pass_count;
/* 逾時、接收失敗或資料不一致都會增加此值，正常應為0。 */
volatile uint32_t error_count;
/* 設為1表示自測流程結束；不代表CPU自動進入debug halt。 */
volatile uint32_t done;
/* 目前送出的byte，Watch可與rx_value比較。 */
volatile uint8_t tx_value;
/* 最近接收到的byte；最後正常為0xFF。 */
volatile uint8_t rx_value;
/* 主程式由純C# startup完成資料初始化與堆疊設定後呼叫。 */
int main(void)
{
    /* 建立已知狀態：停Timer／中斷、設P0輸出、UART恢復115200並清殘留RX。 */
    board_init();
    /* 迴圈索引用32位，避免uint8_t到255加1繞回而永遠無法結束。 */
    for (uint32_t value = 0; value < 256u; ++value) {
        /* 本輪接收暫存值，透過uart_receive指標參數帶回。 */
        uint8_t received = 0;
        /* 以輪詢次數限制等待，不是精確的微秒或毫秒。 */
        uint32_t timeout = 100000u;
        /* 索引轉成真正的八位UART資料。 */
        tx_value = (uint8_t)value;
        /* 傳完一筆才等回收，避免單一RX暫存器被連續資料覆寫。 */
        uart_send(tx_value);
        /* 等RX valid，並持續遞減逾時次數。 */
        while (!(UART_STATUS & 2u) && timeout) { timeout--; }
        /* 沒有接跳線時通常會走到這裡：記錄失敗並停止後續測試。 */
        if (!timeout) { error_count++; break; }
        /* 明確讀UART DATA取走這筆資料，同時清RX valid。 */
        if (!uart_receive(&received)) { error_count++; break; }
        /* 保留最近結果，供停止後檢查。 */
        rx_value = received;
        /* 以P0顯示實際收到的內容，而非預先假設收到正確資料。 */
        p0_write(received);
        /* 只有收到與送出相同的byte才算通過。 */
        if (received == tx_value) { pass_count++; }
        /* 資料不同也會繼續測下一個byte，最後可由error_count判斷。 */
        else { error_count++; }
    }
    /* 無論正常測完或逾時提前離開，都在此標示流程已結束。 */
    done = 1;
    /* 保留自測結果；請按STOP，或在done賦值行設斷點後觀察。 */
    for (;;) { } /* 在此觀察Watch；程式不會自行使CPU進入debug halt。 */
}
