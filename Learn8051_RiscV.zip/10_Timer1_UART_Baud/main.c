/*
 * 教學：Timer1 overflow 產生 UART 鮑率
 * 接線：TX=P3.6；接收軟體需設定自訂 15625 baud、8-N-1。
 * 流程：Timer1 mode2 每 100 個 50MHz tick 溢位，UART 再除 32，得到 15625。
 * Watch：messages
 * 平台：MAGIC1 RV32IM／ILP32，程式SRAM 512KB、資料BRAM 16KB。
 * 使用方式：F7重新編譯、下載ELF；RUN持續執行，需STOP或斷點才會暫停。
 */
#include "aachip8051.h"

/* 已完整傳送幾次訊息，可由 Watch 與 P0 觀察。 */
volatile uint32_t messages;
/* 主程式由純C# startup完成資料初始化與堆疊設定後呼叫。 */
int main(void)
{
    /* 字串為 ASCII，結尾有 CR/LF；不像 03 範例傳原始計數 byte。 */
    const char *message = "Hello 8051 -> RISC-V!\r\n";
    /* 建立已知狀態：停Timer／中斷、設P0輸出、UART恢復115200並清殘留RX。 */
    board_init();
    /* Timer 每個 50MHz 時脈增加一次；兩個 Timer 都共用此分頻。 */
    TIMER_CLOCK = 1;
    /* 高四位 0010：Timer1 mode2、內部時脈、GATE1 關閉。 */
    TMOD = 0x20;
    /* mode2 自動重載值，溢位間隔為 256-156=100 ticks。 */
    TH1 = 156;
    /* 同時設定首次計數初值，避免第一個週期與之後不同。 */
    TL1 = 156;
    /* bit0=1 選 Timer1，bit1=0 選除32；50MHz/100/32=15625 baud。 */
    UART_CLOCK = 1; /* overflow/32：50MHz/1/100/32=15625 baud。 */
    /* 啟動 Timer1 後 UART 才有鮑率脈波。 */
    TCON = TR1;
    for (;;) {
        /* 每輪把讀取位置重新指向字串開頭。 */
        const char *p = message;
        /* 遇到字串終止字元0便停止，不把終止字元傳出去。 */
        while (*p) { uart_send((uint8_t)*p); p++; }
        /* 字串及 CR/LF 都傳完後才增加次數。 */
        messages++;
        /* P0 顯示訊息次數的低八位。 */
        p0_write((uint8_t)messages);
        soft_delay(100000u);
    }
}
