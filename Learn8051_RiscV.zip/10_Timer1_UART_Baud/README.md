# 10 Timer1 產生 UART 鮑率

接線：P3.6接UART接收器，GND共地；接收端需支援自訂15625 baud。

開啟本目錄的 `10_Timer1_UART_Baud.rvproj`，F7編譯、連線、下載ELF，再按RUN。預設純C# O0，方便單步學習；在實際敘述行設斷點，不選只有大括號的行。

預期結果：每輪送出Hello 8051 -> RISC-V!與換行；P0顯示訊息次數。

Watch：messages。

UART_CLOCK改為3可用SMOD=1得到31250 baud。CLOCK是兩個Timer共用；除錯暫停會凍結Timer1及UART位元時序，連續通訊可設CLOCK bit16，但此時Timer在halt時仍運作。

共同設定及8051差異見 [總說明](../README.md)。測試狀態見 [驗證紀錄](../VALIDATION.md)。

## 程式中文導讀

完整流程與預期結果見 [程式中文說明](程式中文說明.md)。
