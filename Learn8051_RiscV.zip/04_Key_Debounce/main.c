/*
 * 教學：低有效按鍵與約 20ms 去彈跳
 * 接線：按鍵接 P3.2 與 GND，放開時需上拉；按下為 0。
 * 流程：每個 Timer0 旗標取樣一次，候選狀態維持約 20ms 才接受變化。
 * Watch：presses、stable_key、milliseconds
 * 平台：MAGIC1 RV32IM／ILP32，程式SRAM 512KB、資料BRAM 16KB。
 * 使用方式：F7重新編譯、下載ELF；RUN持續執行，需STOP或斷點才會暫停。
 */
#include "aachip8051.h"

/* 已處理的 Timer 取樣旗標次數；輪詢可能漏 tick，並非絕對經過時間。 */
volatile uint32_t milliseconds;
/* 只計算已確認的按下事件，不計算放開事件。 */
volatile uint32_t presses;
/* 已接受的按鍵狀態：1=放開，0=按下。 */
volatile uint8_t stable_key = 1;
/* 主程式由純C# startup完成資料初始化與堆疊設定後呼叫。 */
int main(void)
{
    /* 目前正在等待確認的候選輸入值。 */
    uint8_t candidate = 1;
    /* 候選值保持不變的取樣次數，最多累加到 20。 */
    uint8_t same_ms = 0;
    /* 建立已知狀態：停Timer／中斷、設P0輸出、UART恢復115200並清殘留RX。 */
    board_init();
    /* PORT_BIT(2) 是 P3 bit2；清方向位元表示輸入，不是輸出 0。 */
    P3_DIR &= ~PORT_BIT(2); /* P3.2輸入，高為放開、低為按下。 */
    /* 50MHz／500=100kHz，因此每次 Timer 增加間隔為 10us。 */
    TIMER_CLOCK = 500;      /* 50MHz/500=100kHz。 */
    /* mode2 是八位自動重載；256-156=100 ticks，名目週期 1ms。 */
    TMOD = 2; TH0 = 156; TL0 = 156; /* mode2: 100 ticks=1ms。 */
    /* 啟動 Timer0；本例不開中斷，主迴圈直接檢查 TF0。 */
    TCON = TR0;
    for (;;) {
        /* 只有偵測到溢位旗標時才取樣一次，不以主迴圈速度直接取樣。 */
        if (TCON & TF0) {
            /* ACK bit1 寫 1 清 TF0；不要對 ACK 做讀取後修改。 */
            IRQ_ACK = ET0;
            milliseconds++;
            /* 取得目前腳位電位；先與候選狀態比較，而不是立刻視為新按鍵事件。 */
            uint8_t raw = (P3_IN & PORT_BIT(2)) ? 1u : 0u;
            /* 變化代表可能仍在彈跳，重新開始穩定時間計數。 */
            if (raw != candidate) { candidate = raw; same_ms = 0; }
            /* 候選值未變才累加；達 20 後飽和，避免 uint8_t 繞回。 */
            else if (same_ms < 20u) { same_ms++; }
            /* 僅接受尚未登記的新穩定狀態，因此持續按住不會連續加一。 */
            if (same_ms == 20u && stable_key != candidate) {
                stable_key = candidate;
                /* 只在穩定狀態變為低電位時增加 presses，並顯示其低八位。 */
                if (!stable_key) { presses++; p0_write((uint8_t)presses); }
            }
        }
    }
}
