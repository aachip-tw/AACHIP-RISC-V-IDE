/*
 * 教學：外部 T0 下降緣計數
 * 接線：T0=P3.4，輸入訊號須共地、電位相容，並保持足夠高低時間。
 * 流程：Timer0 設成 16-bit 外部 Counter，讀取一致的高低位後輸出低八位。
 * Watch：count
 * 平台：MAGIC1 RV32IM／ILP32，程式SRAM 512KB、資料BRAM 16KB。
 * 使用方式：F7重新編譯、下載ELF；RUN持續執行，需STOP或斷點才會暫停。
 */
#include "aachip8051.h"

/* 對外呈現目前十六位計數值；65535 之後會回零。 */
volatile uint32_t count;
/* 高低位分開讀取會遇到進位，需讀高、低、再高確認一致。 */
static uint32_t counter_read(void)
{
    uint32_t high1, low, high2;
    do {
        /* 先讀高位。 */
        high1 = TH0;
        /* 再讀低位；此時外部脈波仍可能讓計數器進位。 */
        low = TL0;
        /* 重讀高位；若與第一次不同，就整組重讀。 */
        high2 = TH0;
    } while (high1 != high2);
    return (high2 << 8) | low; /* 避免讀取時低位進位造成不一致。 */
}
/* 主程式由純C# startup完成資料初始化與堆疊設定後呼叫。 */
int main(void)
{
    /* 先停用先前範例留下的中斷和 Timer，再設定本例。 */
    /* 建立已知狀態：停Timer／中斷、設P0輸出、UART恢復115200並清殘留RX。 */
    board_init();
    /* T0 位於 P3.4，也就是 P3 bit4；必須設成輸入。 */
    P3_DIR &= ~PORT_BIT(4);
    /* 0x05=0101b：C/T0=1 選外部下降緣，mode=01 選十六位。 */
    TMOD = 5; /* C/T0=1、mode1、GATE0=0。 */
    /* 清高位與低位，從零開始計數。 */
    TH0 = 0;
    TL0 = 0;
    /* 啟動外部計數；增加速度由輸入下降緣決定，而非 CLOCK 分頻。 */
    TCON = TR0;
    for (;;) {
        /* 取出一致的十六位值供 Watch 查看。 */
        count = counter_read();
        /* P0 只能顯示最低八位，不能由 LED 推定完整十六位結果。 */
        p0_write((uint8_t)count);
    }
}
