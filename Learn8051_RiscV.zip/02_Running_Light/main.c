/*
 * 教學：八位跑馬燈與循環位移
 * 接線：P0.0～P0.7 對應最低八位輸出，外接 LED 需限流。
 * 流程：由 0x01 開始左移，最高位回到最低位，循環走過八個位置。
 * Watch：pattern、shifts
 * 平台：MAGIC1 RV32IM／ILP32，程式SRAM 512KB、資料BRAM 16KB。
 * 使用方式：F7重新編譯、下載ELF；RUN持續執行，需STOP或斷點才會暫停。
 */
#include "aachip8051.h"

/* 以單一有效位元開始，確保每次只輸出一個 1。 */
volatile uint8_t pattern = 1;
/* 記錄已做幾次循環位移，方便在 Watch 確認程式持續執行。 */
volatile uint32_t shifts;
/* 主程式由純C# startup完成資料初始化與堆疊設定後呼叫。 */
int main(void)
{
    /* 建立已知狀態：停Timer／中斷、設P0輸出、UART恢復115200並清殘留RX。 */
    board_init();
    for (;;) {
        /* 顯示目前圖案；LED 若為低有效，視覺效果會相反。 */
        p0_write(pattern);
        /* 保留目前圖案一段時間，不是硬體定時。 */
        soft_delay(100000u);
        /* 左移產生下一個位置；原 bit7 經右移放回 bit0。轉成 uint8_t 截去第九位。 */
        pattern = (uint8_t)((pattern << 1) | (pattern >> 7));
        /* 記錄位移完成；新的 pattern 會在下一輪寫到 P0。 */
        shifts++;
    }
}
