/*
 * 教學：INT0／INT1 與兩級來源仲裁
 * 接線：INT0=P3.2，INT1=P3.3；高變低觸發。
 * 流程：兩者同時 pending 時先服務高優先的 INT1，再服務 INT0。
 * Watch：int0_hits、int1_hits、last_source、heartbeat
 * 平台：MAGIC1 RV32IM／ILP32，程式SRAM 512KB、資料BRAM 16KB。
 * 使用方式：F7重新編譯、下載ELF；RUN持續執行，需STOP或斷點才會暫停。
 */
#include "aachip8051.h"

/* INT0 中斷累計次數，由 ISR 增加。 */
volatile uint32_t int0_hits;
/* INT1 中斷累計次數，由 ISR 增加。 */
volatile uint32_t int1_hits;
/* 0xFFFFFFFF 表示目前尚未服務任何來源；其後記錄最近的來源編號。 */
volatile uint32_t last_source = 0xffffffffu;
/* 確認中斷服務後仍可返回主迴圈。 */
volatile uint32_t heartbeat;
/* 固定 trap 入口由 startup 跳到此函式；不使用 8051 的 interrupt n 語法。 */
__attribute__((interrupt("machine"))) void aachip_machine_trap(void)
{
    /* 在 ISR 一開始取得仲裁結果；一次只服務這一個來源。 */
    uint32_t source = IRQ_ID;
    /* 可設斷點觀察來源順序；兩者同時 pending 時先看到 2，之後看到 0。 */
    last_source = source;
    /* IRQ_ID=0 是 INT0，ACK 遮罩 EX0=bit0。 */
    if (source == 0u) { int0_hits++; IRQ_ACK = EX0; }
    /* IRQ_ID=2 是 INT1，ACK 遮罩 EX1=bit2。 */
    else if (source == 2u) { int1_hits++; IRQ_ACK = EX1; }
}
/* 主程式由純C# startup完成資料初始化與堆疊設定後呼叫。 */
int main(void)
{
    /* 將 P3.2／P3.3 設成輸入，避免按鍵接地時與輸出驅動衝突。 */
    board_init(); P3_DIR &= ~(PORT_BIT(2) | PORT_BIT(3));
    /* 0x05 使 IT0、IT1 均為 1，因此採下降緣觸發。 */
    TCON = 5; /* IT0=IT1=1，下降緣觸發。 */
    /* IP bit2=1 提高 INT1 的仲裁優先序，並不開啟中斷巢狀。 */
    IP = EX1; /* INT1為高優先；兩者同時pending時先服務INT1。 */
    /* 開啟周邊總開關與兩個來源，再開啟 CPU 中斷接收。 */
    IE = EA | EX0 | EX1; cpu_irq_enable();
    for (;;) {
        /* INT0 次數放低四位，INT1 次數放高四位；各顯示模 16 的結果。 */
        p0_write((uint8_t)((int0_hits & 15u) | ((int1_hits & 15u) << 4)));
        heartbeat++;
    }
}
