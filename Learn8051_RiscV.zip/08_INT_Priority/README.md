# 08 INT0／INT1 與兩級優先序

接線：INT0=P3.2、INT1=P3.3，可用按鍵接GND或外部訊號；均有弱上拉。

開啟本目錄的 `08_INT_Priority.rvproj`，F7編譯、連線、下載ELF，再按RUN。預設純C# O0，方便單步學習；在實際敘述行設斷點，不選只有大括號的行。

預期結果：INT0更新P0低4位，INT1更新高4位；同時pending時INT1先服務。

Watch：int0_hits、int1_hits、last_source、heartbeat。

這是來源仲裁優先序，不提供完整8051中斷巢狀機制。按鍵彈跳可能多次觸發。

共同設定及8051差異見 [總說明](../README.md)。測試狀態見 [驗證紀錄](../VALIDATION.md)。

## 程式中文導讀

完整流程與預期結果見 [程式中文說明](程式中文說明.md)。
