/*
 * 8051風格周邊的RISC-V C共用介面。
 * 所有IO32皆為volatile 32-bit MMIO；不能當一般RAM任意快取或合併存取。
 * 本板P0～P3各使用bit0..7；舊GPIO32介面保留。GPIO是明確方向，並非8051準雙向埠。
 * 原理與限制請搭配各範例README閱讀。
 */
#ifndef AACHIP_8051_LEARNING_H
#define AACHIP_8051_LEARNING_H
/* 使用明確寬度的uint8_t／uint32_t，避免把C型別長度與8051習慣混淆。 */
#include <stdint.h>
/* 這是 RISC-V MMIO，並非 8051 的 SFR 位址或 sbit 語法。 */
/* 把數值位址轉成volatile指標再解參考；每次讀寫都必須實際存取硬體。 */
#define IO32(address) (*(volatile uint32_t *)(address))
/* 寫入低八位啟動TX；讀取取得RX byte並清RX valid，有副作用。 */
#define UART_DATA IO32(0xF0000000u)
/* bit0=TX busy，bit1=RX valid；讀此狀態不會清除接收資料。 */
#define UART_STATUS IO32(0xF0000004u)
/* 32-bit輸出鎖存，輸入方向的腳位仍可保留其輸出鎖存值。 */
#define GPIO_OUT IO32(0xF0000100u)
/* 讀同步後的實體腳位電位，不是GPIO_OUT的軟體副本。 */
#define GPIO_IN IO32(0xF0000104u)
/* 方向位元1=輸出、0=輸入；不可把外部輸入腳設成輸出互相驅動。 */
#define GPIO_DIR IO32(0xF0000108u)
/* bit0=1把P3.6／P3.7交給UART，0則回到GPIO。 */
#define GPIO_ALT IO32(0xF000010cu)
/* Four independent 8-bit ports, accessed with aligned 32-bit MMIO.
 * Only bits 0..7 are implemented. Writes preserve the other three ports. */
#define PORT_OUT(n) IO32(0xF0000140u + ((n) * 16u))
#define PORT_IN(n)  IO32(0xF0000144u + ((n) * 16u))
#define PORT_DIR(n) IO32(0xF0000148u + ((n) * 16u))
#define P0 PORT_OUT(0u)
#define P0_OUT PORT_OUT(0u)
#define P0_IN PORT_IN(0u)
#define P0_DIR PORT_DIR(0u)
#define P1 PORT_OUT(1u)
#define P1_OUT PORT_OUT(1u)
#define P1_IN PORT_IN(1u)
#define P1_DIR PORT_DIR(1u)
#define P2 PORT_OUT(2u)
#define P2_OUT PORT_OUT(2u)
#define P2_IN PORT_IN(2u)
#define P2_DIR PORT_DIR(2u)
#define P3 PORT_OUT(3u)
#define P3_OUT PORT_OUT(3u)
#define P3_IN PORT_IN(3u)
#define P3_DIR PORT_DIR(3u)

/* bit7..0：TF1、TR1、TF0、TR0、IE1、IT1、IE0、IT0。 */
#define TCON IO32(0xF0000200u)
/* 每Timer四位：GATE、C/T、M1、M0；低四位T0、高四位T1。 */
#define TMOD IO32(0xF0000204u)
/* Timer0低位；mode0只用低五位，mode3則成獨立八位TL0。 */
#define TL0 IO32(0xF0000208u)
/* Timer0高位／mode2重載值；mode3成獨立八位TH0。 */
#define TH0 IO32(0xF000020cu)
/* Timer1低位／mode2目前計數值。 */
#define TL1 IO32(0xF0000210u)
/* Timer1高位／mode2自動重載值，會影響Timer1 UART鮑率。 */
#define TH1 IO32(0xF0000214u)
/* 周邊中斷使能：EA bit7，INT0／T0／INT1／T1為bit0..3。 */
#define IE IO32(0xF0000218u)
/* 來源優先序：bit0..3對應四個來源，1高優先、0低優先；不等於ISR巢狀。 */
#define IP IO32(0xF000021cu)
/* 已經套用EA與IE遮罩的pending位元，唯讀。 */
#define IRQ_PENDING IO32(0xF0000220u)
/* 回傳仲裁選中的編號0/1/2/3；無來源時為0xFFFFFFFF。 */
#define IRQ_ID IO32(0xF0000224u)
/* Write-one-to-clear：bit0..3各自清除四個來源旗標，不能用|=。 */
#define IRQ_ACK IO32(0xF0000228u)
/* 低16位是50MHz分頻，0視為1；bit16=1允許debug halt期間繼續計數。 */
#define TIMER_CLOCK IO32(0xF000022cu)
/* bit0選Timer1 overflow，bit1為SMOD：0除32、1除16；全0使用固定115200。 */
#define UART_CLOCK IO32(0xF0000230u)
/* Timer0啟動控制bit4；mode3時只控制TL0。 */
#define TR0 0x10u
/* Timer0溢位旗標bit5；mode3時由TL0溢位設定。 */
#define TF0 0x20u
/* Timer1啟動控制bit6；Timer0 mode3時改控制TH0。 */
#define TR1 0x40u
/* Timer1溢位旗標bit7；Timer0 mode3時由TH0溢位設定。 */
#define TF1 0x80u
/* IE的周邊總開關；CPU端仍須另開mstatus.MIE與mie.MEIE。 */
#define EA 0x80u
/* INT0來源遮罩bit0，也用於IE、IP與IRQ_ACK。 */
#define EX0 1u
/* Timer0來源遮罩bit1；不是IRQ_ID回傳的編號。 */
#define ET0 2u
/* INT1來源遮罩bit2。 */
#define EX1 4u
/* Timer1／split TH0來源遮罩bit3。 */
#define ET1 8u
/* P0～P3各自使用bit0..7，例如P3.2使用PORT_BIT(2)。 */
#define PORT_BIT(n) (1u << (n))

/* 獨立P0寫入保留其他Port；若ISR也寫同一Port須另作同步。 */
static void p0_write(uint8_t value)
{
    /* 硬體只更新P0的八位輸出鎖存。 */
    P0 = value;
}

/* 每個範例開始先建立一致狀態；不在ISR或正常收發途中反覆呼叫。 */
static void board_init(void)
{
    /* 停止前一個範例留下的中斷／Timer，建立一致的起始狀態。 */
    /* 關閉CPU全域中斷與全部mie來源，避免沿用前一範例的中斷設定。 */
    __asm__ volatile ("csrci mstatus, 8\ncsrw mie, zero" ::: "memory");
    /* 先關周邊中斷，再停止Timer，最後清旗標與模式，避免設定途中觸發。 */
    IE = 0;
    TCON = 0;
    /* 四個ACK位元全寫1；低電位型INT若腳仍低，旗標仍可重新出現。 */
    IRQ_ACK = 15;
    TMOD = 0;
    IP = 0;
    /* 預設採50MHz/12計時；各Timer範例會依需要覆寫。 */
    TIMER_CLOCK = 12;
    /* 預設使用獨立115200鮑率，不依賴Timer1是否啟動。 */
    UART_CLOCK = 0;
    /* 先解除P3.6／P3.7的GPIO輸出驅動，再啟用UART替代功能。 */
    P3_DIR &= ~0xc0u; /* UART P3.6/P3.7 不由 GPIO 驅動。 */
    GPIO_ALT |= 1u;
    p0_write(0);
    P0_DIR = 0xffu;
    /* 明確清除前次殘留的 RX；一般更新暫存器不應讀此位址。 */
    /* 此處刻意丟棄上一範例殘留的RX；正式接收流程應保存其回傳值。 */
    if (UART_STATUS & 2u) { (void)UART_DATA; }
}

/* 周邊IE設定完成後才開啟CPU接收；與8051只設定EA的做法不同。 */
static void cpu_irq_enable(void)
{
    /* MEIE=bit11、mstatus.MIE=bit3；ISR 返回須用 mret。 */
    __asm__ volatile ("li t0, 0x800\ncsrw mie, t0\ncsrsi mstatus, 8" ::: "t0", "memory");
}

/* 阻塞式示範延遲；loops是迴圈次數，不能解讀為毫秒。 */
static void soft_delay(uint32_t loops)
{
    /* 軟體延遲只供觀察，不保證精確時間。 */
    for (volatile uint32_t i = 0; i < loops; ++i) { }
}

/* 阻塞傳送單一byte，開始前與結束後都確認TX busy，方便教學觀察順序。 */
static void uart_send(uint8_t value)
{
    /* 等待硬體完成；若選Timer1鮑率卻停止Timer1，會一直停在等待中。 */
    while (UART_STATUS & 1u) { }
    /* 寫入資料低八位；此函式不另外加換行或做ASCII編碼。 */
    UART_DATA = value;
    /* 等待硬體完成；若選Timer1鮑率卻停止Timer1，會一直停在等待中。 */
    while (UART_STATUS & 1u) { } /* 確認 stop bit 已完成。 */
}

/* 非阻塞接收：有資料回傳1並寫入*value，沒資料回傳0且不改*value。 */
static int uart_receive(uint8_t *value)
{
    /* 先看狀態再決定是否讀DATA，避免無資料時把舊值當成新資料。 */
    if (!(UART_STATUS & 2u)) return 0;
    /* 此讀取會消耗目前RX；只有單一暫存器，未讀前新資料可能覆寫。 */
    *value = (uint8_t)UART_DATA; /* 讀取會清 RX valid。 */
    return 1;
}
#endif
