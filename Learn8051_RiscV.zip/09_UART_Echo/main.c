/*
 * 教學：UART 輪詢接收與回送
 * 接線：正常連 PC 時移除 P3.6／P3.7 短接；外部 TX→P3.7、RX←P3.6。
 * 流程：收到一個 byte 就顯示到 P0，再原樣傳回；請用單 byte 送出後等待回送。
 * Watch：received、echo_count
 * 平台：MAGIC1 RV32IM／ILP32，程式SRAM 512KB、資料BRAM 16KB。
 * 使用方式：F7重新編譯、下載ELF；RUN持續執行，需STOP或斷點才會暫停。
 */
#include "aachip8051.h"

/* 保留最後收到的 byte，方便 Watch 查看。 */
volatile uint8_t received;
/* 已完成回送的次數；此處不是接收 FIFO 的長度。 */
volatile uint32_t echo_count;
/* 主程式由純C# startup完成資料初始化與堆疊設定後呼叫。 */
int main(void)
{
    /* 暫存本次收到的 byte，由 uart_receive 透過指標寫入。 */
    uint8_t value;
    /* 建立已知狀態：停Timer／中斷、設P0輸出、UART恢復115200並清殘留RX。 */
    board_init();
    for (;;) {
        /* 僅在 RX valid=1 時讀資料；讀 UART_DATA 會清除接收旗標。 */
        if (uart_receive(&value)) {
            /* 先保留本次資料，之後硬體 RX 暫存器可能被下一筆覆寫。 */
            received = value;
            /* P0 顯示原始八位資料，不做 ASCII 或數字轉換。 */
            p0_write(value);
            /* 回送同一 byte，等待傳送完成才返回。 */
            uart_send(value);
            /* 此行適合設斷點：此時回送已完成。只有一個 RX 暫存器，請勿高速連發。 */
            echo_count++;
        }
    }
}
