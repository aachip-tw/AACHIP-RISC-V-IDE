/*
 * 教學：Timer0 mode1 輪詢與軟體重載
 * 接線：觀察 P0.0，不需要外部時脈訊號。
 * 流程：以 100kHz 計數，從 0xFC18 數到溢位約 10ms，50 次後反轉 LED。
 * Watch：ticks、led
 * 平台：MAGIC1 RV32IM／ILP32，程式SRAM 512KB、資料BRAM 16KB。
 * 使用方式：F7重新編譯、下載ELF；RUN持續執行，需STOP或斷點才會暫停。
 */
#include "aachip8051.h"

/* 已由軟體處理的溢位次數，非 Timer 內部計數器本身。 */
volatile uint32_t ticks;
volatile uint8_t led;
/* 主程式由純C# startup完成資料初始化與堆疊設定後呼叫。 */
int main(void)
{
    /* 將名目 10ms 事件再除以 50，得到約 0.5 秒翻轉間隔。 */
    uint32_t divider = 0;
    /* 建立已知狀態：停Timer／中斷、設P0輸出、UART恢復115200並清殘留RX。 */
    board_init();
    TIMER_CLOCK = 500; /* 100kHz，1000 ticks=10ms。 */
    /* Timer0 mode1：TH0 與 TL0 合成十六位，不會自動重載。 */
    TMOD = 1;
    /* 初值 0xFC18=64536，到 65536 尚有 1000 次增加。 */
    TH0 = 0xfcu; TL0 = 0x18u; /* 65536-1000=0xFC18。 */
    /* 允許 Timer0 內部計時。 */
    TCON = TR0;
    for (;;) {
        /* 偵測溢位後才進行重載和軟體累加。 */
        if (TCON & TF0) {
            /* 暫停 Timer，清對應旗標並重新裝入初值，再啟動。 */
            TCON = 0; IRQ_ACK = ET0;
            /* 初值 0xFC18=64536，到 65536 尚有 1000 次增加。 */
            TH0 = 0xfcu; TL0 = 0x18u; TCON = TR0;
            /* 每完成一次重載才登記一個 tick。 */
            ticks++;
            /* 滿 50 次便反轉 P0.0；實際週期還包含輪詢及重載開銷。 */
            if (++divider == 50u) { divider = 0; led ^= 1u; p0_write(led); }
        }
    }
}
