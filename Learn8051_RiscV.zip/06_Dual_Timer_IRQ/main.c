/*
 * 教學：雙 Timer mode2 與機器模式中斷
 * 接線：P0.0 顯示 Timer0 分頻，P0.1 顯示 Timer1 分頻。
 * 流程：Timer 自動重載；ISR 只累加與 ACK，主迴圈計算 LED 輸出。
 * Watch：timer0_hits、timer1_hits、heartbeat
 * 平台：MAGIC1 RV32IM／ILP32，程式SRAM 512KB、資料BRAM 16KB。
 * 使用方式：F7重新編譯、下載ELF；RUN持續執行，需STOP或斷點才會暫停。
 */
#include "aachip8051.h"

/* ISR 會寫入、主程式會讀取，因此宣告 volatile。 */
volatile uint32_t timer0_hits;
/* Timer1 中斷次數；此範例中只有 ISR 會增加。 */
volatile uint32_t timer1_hits;
/* 主迴圈心跳，可確認 ISR 有正確返回而沒有卡在中斷中。 */
volatile uint32_t heartbeat;
/* 使用 Aachip 的機器中斷屬性，編譯器保存暫存器並以 mret 返回。 */
__attribute__((interrupt("machine"))) void aachip_machine_trap(void)
{
    /* IRQ_ID 回傳已啟用來源中優先序最高的一個，不是旗標遮罩。 */
    uint32_t source = IRQ_ID; /* 每次依優先序處理一個來源。 */
    /* 編號 1 代表 Timer0；必須明確 ACK，並非進入 ISR 後自動清旗標。 */
    if (source == 1u) { timer0_hits++; IRQ_ACK = ET0; }
    /* 編號 3 代表 Timer1；ISR 保持短小，不在此延遲或阻塞傳 UART。 */
    else if (source == 3u) { timer1_hits++; IRQ_ACK = ET1; }
}
/* 主程式由純C# startup完成資料初始化與堆疊設定後呼叫。 */
int main(void)
{
    /* 建立已知狀態：停Timer／中斷、設P0輸出、UART恢復115200並清殘留RX。 */
    board_init();
    /* 兩個 Timer 共用 100kHz 計時來源；TMOD=0x22 表示兩者都是 mode2。 */
    TIMER_CLOCK = 500; TMOD = 0x22;
    /* 256-156=100 ticks，名目 1ms 自動重載。 */
    TH0 = 156; TL0 = 156; /* 1ms。 */
    /* 256-56=200 ticks，名目 2ms 自動重載。 */
    TH1 = 56; TL1 = 56;   /* 2ms。 */
    /* 打開周邊總開關與兩個 Timer 來源，再啟動兩個 Timer。 */
    IE = EA | ET0 | ET1; TCON = TR0 | TR1;
    /* 還要設定 RISC-V CPU 的 MEIE 與 MIE，中斷才會送到 C ISR。 */
    cpu_irq_enable();
    for (;;) {
        /* 每 500 次 Timer0 中斷翻轉 bit0，名目約 0.5 秒。 */
        uint8_t value = (uint8_t)((timer0_hits / 500u) & 1u);
        /* 每 500 次 Timer1 中斷翻轉 bit1，名目約 1 秒。 */
        value |= (uint8_t)(((timer1_hits / 500u) & 1u) << 1);
        p0_write(value);
        /* 主迴圈持續工作；volatile 不是複合操作的原子性保證。 */
        heartbeat++;
    }
}
