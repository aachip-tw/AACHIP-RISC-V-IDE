# 06 Timer0／1 自動重載中斷

接線：P0.0/P0.1 LED；無額外訊號線。

開啟本目錄的 `06_Dual_Timer_IRQ.rvproj`，F7編譯、連線、下載ELF，再按RUN。預設純C# O0，方便單步學習；在實際敘述行設斷點，不選只有大括號的行。

預期結果：T0約1ms、T1約2ms中斷；P0.0約0.5秒翻轉、P0.1約1秒翻轉。

Watch：timer0_hits、timer1_hits、heartbeat。

純C# startup提供固定0x80000020入口，ISR以mret返回。不要在ISR加入阻塞UART或長延遲。

共同設定及8051差異見 [總說明](../README.md)。測試狀態見 [驗證紀錄](../VALIDATION.md)。

## 程式中文導讀

完整流程與預期結果見 [程式中文說明](程式中文說明.md)。
